package com.sample.qe.api.builders;

import static io.restassured.config.EncoderConfig.encoderConfig;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;


import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.serenitybdd.rest.SerenityRest;

public class SerenityRequestHelper  {
	PrintStream log = null;

	SerenityRequestHelper() throws FileNotFoundException {
		String logDate = now("dd.MMMMM.yyyyhh.mm.ss");
	//	log = new PrintStream(new FileOutputStream(System.getProperty("log.dir", "projectPath" + File.separator
	//			+ File.separator + "testLogs" + File.separator + "ApplicationLog_" + logDate + ".log")));
	}

	public RequestSpecification getRequestSpecification() {
		return new RequestSpecBuilder().build();
	}

	public Response post(RequestSpecification specifications) {

		return SerenityRest.given()
				.config(RestAssured.config()
						.encoderConfig(encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)))
				.relaxedHTTPSValidation().spec(specifications).filter(RequestLoggingFilter.logRequestTo(log))
				.filter(ResponseLoggingFilter.logResponseTo(log)).log().all(true).when().post();
	}

	public Response get(RequestSpecification specifications) {

		return SerenityRest.given()
				.config(RestAssured.config()
						.encoderConfig(encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)))
				.relaxedHTTPSValidation().spec(specifications).filter(RequestLoggingFilter.logRequestTo(log))
				.filter(ResponseLoggingFilter.logResponseTo(log)).log().all(true).when().get();
	}

	public Response delete(RequestSpecification specifications) {
		return SerenityRest.given()
				.config(RestAssured.config()
						.encoderConfig(encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)))
				.relaxedHTTPSValidation().spec(specifications).filter(RequestLoggingFilter.logRequestTo(log))
				.filter(ResponseLoggingFilter.logResponseTo(log)).log().all(true).when().delete();
	}

	public Response patch(RequestSpecification specifications) {
		return SerenityRest.given()
				.config(RestAssured.config()
						.encoderConfig(encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)))
				.relaxedHTTPSValidation().spec(specifications).filter(RequestLoggingFilter.logRequestTo(log))
				.filter(ResponseLoggingFilter.logResponseTo(log)).log().all(true).when().patch();
	}

	public Response put(RequestSpecification specifications) {
		return SerenityRest.given()
				.config(RestAssured.config()
						.encoderConfig(encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)))
				.relaxedHTTPSValidation().spec(specifications).filter(RequestLoggingFilter.logRequestTo(log))
				.filter(ResponseLoggingFilter.logResponseTo(log)).log().all(true).when().put();
	}

	public static String now(String dateFormat) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
		return sdf.format(cal.getTime());
	}
}
