package com.sample.qe.api.endpoints;

public class APIEndPoints {


    public static final String ENDPOINT = "https://od-api-demo.oxforddictionaries.com:443/api/v1/domains/{source_domains_language}/{target_domains_language}";

    
    
}