package com.sample.qe.api.pojos;

import java.util.Map;

public class Environment {
    
    private String name;
    private Map<String, Object> products;
    
    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
    
    public void setProducts(Map<String, Object> products) {
        this.products = products;
    }
    public Map<String, Object> getProducts() {
        return products;
    }
}