package com.sample.qe.api.runnerfile;

import org.junit.runner.RunWith;

//import com.sample.qe.api.base.SerenityBase;

import io.cucumber.junit.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(monochrome = true, features = "src/test/resources/features/", tags = "@AddPlace", glue = {
		"com.sample.qe.api.stepdefinitions" }, plugin = { "html:target/cucumber", "json:target/cucumber.json",
				"junit:target/cucumber.xml" })

public class RunnerCukes  {
}