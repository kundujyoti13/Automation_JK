package com.sample.qe.api.builders;

import java.util.List;
import java.util.Map;

import com.sample.qe.api.utility.Utility;
import org.junit.Assert;


import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.Headers;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class SerenityResponseHelper {

    public static Response response;

    public RequestSpecification getRequestSpecification() {
        return new RequestSpecBuilder().build();
    }

    public void assertStatusCode(int statusCode, Response response) {
        response.then().statusCode(statusCode);
    }

    public String getString(String jsonPath, Response response) {
        return response.then().extract().jsonPath().getString(jsonPath);
    }

    public int getInt(String jsonPath, Response response) {
        return response.then().extract().jsonPath().getInt(jsonPath);
    }

    public boolean getBoolean(String jsonPath, Response response) {
        return response.then().extract().jsonPath().getBoolean(jsonPath);
    }

    public List getList(String jsonPath, Response response) {
        return response.then().extract().jsonPath().getList(jsonPath);
    }

    public void validateJsonSchema(String schema, Response response) {
        response.then().assertThat()
                .body(JsonSchemaValidator.matchesJsonSchema(Utility.readResponseJsonSchema(schema)));

    }

    public String getDataFromResponseUsingJsonPath(String jsonPath) {
        response.prettyPrint();
        return response.then().extract().jsonPath().getString(jsonPath);
    }

    public List<Object> getListFromResponseUsingJsonPath(String jsonPath) {
        return response.then().extract().jsonPath().getList(jsonPath);
    }

    public List<String> getListFromResponseUsingJsonPath1(String jsonPath) {
        return response.then().extract().body().jsonPath().getList(jsonPath);
    }

    public List<Map> getListofMapFromResponseUsingJsonPath(String jsonPath) {
        return response.then().extract().jsonPath().getList(jsonPath);
    }

    public Map<String, Object> getMapFromResponseUsingJsonPath(String jsonPath) {
        return response.then().extract().jsonPath().getMap(jsonPath);
    }

    public void assertReponseStatus(int expectedStatusCode) {
        response.prettyPrint();
        response.then().statusCode(expectedStatusCode);

    }

    public void validateJsonSchema(String schema) {
        response.prettyPrint();
        response.then().assertThat()
                .body(JsonSchemaValidator.matchesJsonSchema(Utility.readResponseJsonSchema(schema)));

    }

    public static boolean getBooleanDataFromResponseUsingJsonPath(String jsonPath) {

        return response.then().extract().jsonPath().getBoolean(jsonPath);
    }

    public static Headers getResponseHeaders() {
        return response.getHeaders();
    }

    public static List<Map<String, Object>> getMapListFromResponseUsingJsonPath(String jsonPath) {

        return response.then().extract().jsonPath().prettyPeek().getList(jsonPath);
    }

    public static int getIntDataFromResponseUsingJsonPath(String jsonPath) {
        return response.then().extract().jsonPath().prettyPeek().getInt(jsonPath);
    }

    public static String getStringDataFromResponseUsingJsonPath(String jsonPath) {
        return response.then().extract().jsonPath().prettyPeek().getString(jsonPath);
    }

    public static List getList(String jsonPath) {
        return response.then().extract().jsonPath().prettyPeek().getList(jsonPath);
    }

    public static Map<String, ?> getMap(String jsonPath) {
        return response.then().extract().jsonPath().prettyPeek().getMap(jsonPath);
    }

    public static String getJsonPath(Response response, String key) {

        if (response.body().asString() == null) {
            Assert.fail("Json Response coming is null");
        }
        String resp = response.asString();
        JsonPath js = new JsonPath(resp);
        return js.get(key).toString();

    }

}