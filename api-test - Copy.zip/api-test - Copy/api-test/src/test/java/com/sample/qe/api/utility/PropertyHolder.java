package com.sample.qe.api.utility;

import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

//import com.sample.qe.api.base.SerenityBase;

import net.serenitybdd.core.Serenity;

public class PropertyHolder  {

    public static final Map<String, String> propertyMap = new HashMap<>();
    public static String getProperty(String attribute) {
        return propertyMap.get(attribute);
    }

    public static Set<Entry<String, String>> getAllProperty() {
        return propertyMap.entrySet();
    }

    public static void setProperty(String attribute, String value) {
        propertyMap.put(attribute, value);
    }

    public static void setProperties(Map<String, String> map) {
        propertyMap.putAll(map);
    }
    
    public static boolean booleanProperty(String attribute) {
		return propertyMap.containsKey(attribute);
	}

    public static boolean containsvalue(String attribute) {
		return propertyMap.containsValue(attribute);
	}


}