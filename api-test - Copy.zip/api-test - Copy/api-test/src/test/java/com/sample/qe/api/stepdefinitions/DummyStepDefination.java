package com.sample.qe.api.stepdefinitions;

import com.sample.qe.api.builders.SerenityRequestHelper;
import com.sample.qe.api.builders.SerenityResponseHelper;
import com.sample.qe.api.pojos.AddPlace;
import com.sample.qe.api.utility.APIResources;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import net.thucydides.core.annotations.Steps;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class DummyStepDefination {
    @Steps(shared = true)
    SerenityRequestHelper serenityRestHelper;
    @Steps(shared = true)
    SerenityResponseHelper responseHelper;

    Map<String, String> headers = new HashMap<String, String>();
    Map<String, String> pathParam = new HashMap<String, String>();

    RequestSpecification res;
    ResponseSpecification resspec;

    private AddPlace placeJsonBody;
    static String place_id;
    APIResources resourceAPI = null;

    public Response response;


    @When("user calls {string} with Post request")
    public void user_calls_with_http_request(String resource) throws IOException {
        // Write code here that turns the phrase above into concrete actions
        // constructor will be called with value of resource which you pass
       // resourceAPI = APIResources.valueOf(resource);
       // response = serenityRestHelper.post(serenityRestHelper.getRequestSpecification().baseUri("Constants.BASE_URL")
         //       .basePath(resourceAPI.getResource()).contentType(ContentType.JSON).body(placeJsonBody));
      //  response.prettyPrint();
        System.out.println("HEllo JK");
    }

    @Then("the API call got success with status code {int}")
    public void the_API_call_got_success_with_status_code(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
    //    assertEquals(response.getStatusCode(), 200);
        System.out.println("HEllo verify 3 JK");

    }

    @Then("{string} in response body is {string}")
    public void in_response_body_is(String keyValue, String Expectedvalue) {
        // Write code here that turns the phrase above into concrete actions
       // assertEquals(SerenityResponseHelper.getStringDataFromResponseUsingJsonPath(keyValue), Expectedvalue);
        System.out.println("HEllo response 4 JK");
    }


    @Then("verify place_Id created maps to {string} using {string}")
    public void verify_place_Id_created_maps_to_using(String expectedName, String resource) throws IOException {

        // requestSpec
       // place_id = SerenityResponseHelper.getJsonPath(response, "place_id");
     //   resourceAPI = APIResources.valueOf(resource);
       // response = serenityRestHelper.get(serenityRestHelper.getRequestSpecification()
         //       .contentType("application/json").accept("application/json").baseUri("Constants.BASE_URL")
          //      .basePath(resourceAPI.getResource()).queryParam("place_id", place_id));
        //response.then().assertThat().statusLine("HTTP/1.1 200 OK");
		/*String actualName = SerenityResponseHelper.getStringDataFromResponseUsingJsonPath("name");
		assertEquals(actualName, expectedName);*/

        System.out.println("hello 2 JK");

    }

}
