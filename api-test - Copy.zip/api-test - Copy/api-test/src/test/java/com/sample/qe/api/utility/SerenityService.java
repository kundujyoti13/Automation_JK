package com.sample.qe.api.utility;

import java.util.Map;

import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.minidev.json.JSONObject;
import net.serenitybdd.rest.SerenityRest;

public class SerenityService {

	public static EncoderConfig encoderconfig = new EncoderConfig();

	/**
	 * Wrapper method which makes a restassured post call with form parameter
	 * 
	 * @param formParams
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response preemptiveAuthWithFormParam(Map<String, String> formParams, String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().formParams(formParams)
				.contentType(getContentType(contentType)).auth().preemptive().basic("system", "glpApp").log().all()
				.when().post(URL);
	}

	/**
	 * Wrapper method which makes simple restassured get call
	 *
	 * @param URL
	 * @return response
	 */
	public static Response getCall(String URL) {
		return SerenityRest.get(URL);
	}

	/**
	 * Wrapper method which makes a restassured get call with header parameter
	 * 
	 * @param headers
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response getCallWithHeader(Map<String, String> headers, String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().headers(headers).contentType(getContentType(contentType))
				.when().log().all().get(URL);
	}

	/**
	 * Wrapper method which makes a restassured get call with header path
	 * parameter
	 * 
	 * @param headers
	 * @param pathParam
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response getCallWithHeaderAndPathParam(Map<String, String> headers, Map<String, String> pathParam,
			String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().headers(headers).pathParams(pathParam)
				.contentType(getContentType(contentType)).log().all().when().get(URL);
	}

	/**
	 * Wrapper method which makes a restassured get call without any parameter
	 * 
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response getCallWithContentType(String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().contentType(getContentType(contentType)).log().all().when()
				.get(URL);
	}

	/**
	 * Wrapper method which makes a restassured get call with header and query
	 * parameter
	 * 
	 * @param headers
	 * @param pathParam
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response getCallWithHeaderAndQueryParam(Map<String, String> headers, Map<String, String> pathParam,
			String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().headers(headers).queryParams(pathParam)
				.contentType(getContentType(contentType)).log().all().when().get(URL);
	}

	/**
	 * Wrapper method which makes a restassured post call with form parameter
	 * 
	 * @param formParams
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response postCallWithFormParam(Map<String, String> formParams, String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().formParams(formParams)
				.contentType(getContentType(contentType)).log().all().when().post(URL);
	}

	/**
	 * Wrapper method which makes a restassured post call with headers and form
	 * parameter
	 * 
	 * @param headers
	 * @param formParam
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response postCallWithHeaderAndFormParam(Map<String, String> headers, Map<String, String> formParam,
			String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().headers(headers).formParams(formParam)
				.contentType(getContentType(contentType)).log().all().when().post(URL);
	}

	/**
	 * Wrapper method which makes a restassured post call with headers and form
	 * parameter
	 * 
	 * @param jsonObject
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response postCallWithJsonBodyParam(JSONObject jsonObject, String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().contentType(getContentType(contentType))
				.body((Object) jsonObject).log().all().when().post(URL);
	}

	/**
	 * Wrapper method which makes a restassured post call with body and path
	 * parameter
	 * 
	 * @param jsonObject
	 * @param URL
	 * @param contentType
	 * @return @
	 */

	public static Response postCallWithJsonBodyAndPathParam(String jsonBodyAsString, Map<String, Object> pathParam,
			String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().contentType(getContentType(contentType))
				.pathParams(pathParam).body(jsonBodyAsString).log().all().when().post(URL);
	}

	/**
	 * Wrapper method which makes a restassured post call with header and body
	 * parameter
	 * 
	 * @param headers
	 * @param jsonBodyAsString
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response postCallWithHeaderAndJsonBodyParam(Map<String, String> headers, String jsonBodyAsString,
			String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().headers(headers).contentType(getContentType(contentType))
				.body(jsonBodyAsString).log().all().when().post(URL);
	}

	public static Response postCallWithHeaderAndBodyParam(Map<String, String> headers, String jsonBodyAsString,
			String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().headers(headers).contentType(getContentType(contentType))
				.body(jsonBodyAsString).log().all().when().post(URL);
	}

	public static Response postCallWithHeaderAndPathParmAndBodyParam(Map<String, String> headers,
			Map<String, String> pathParam, String jsonBodyAsString, String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().headers(headers).pathParams(pathParam)
				.contentType(getContentType(contentType)).body(jsonBodyAsString).log().all().when().post(URL);
	}

	/**
	 * Wrapper method which makes a restassured post call with header and
	 * content type only
	 * 
	 * @param headers
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response postCallWithHeaderParam(Map<String, String> headers, String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().headers(headers).contentType(getContentType(contentType))
				.log().all().when().post(URL);
	}

	public static Response deleteCallWithHeaderAndPathParam(Map<String, String> headers, String jsonBodyAsString,
			String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().headers(headers).contentType(getContentType(contentType))
				.body(jsonBodyAsString).log().all().when().delete(URL);
	}

	/**
	 * Wrapper method which makes a restassured delete call with only content
	 * type
	 * 
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response deleteCallWithPathParam(String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().contentType(getContentType(contentType)).log().all().when()
				.delete(URL);
	}

	/**
	 * Wrapper method which makes a restassured delete call with header and
	 * content type
	 * 
	 * @param headers
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response deleteCallWithHeaderAndPathParamWithoutRequestBody(Map<String, String> headers,
			Map<String, String> pathParam, String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().headers(headers).contentType(getContentType(contentType))
				.pathParams(pathParam).log().all().when().delete(URL);
	}

	/**
	 * Wrapper method which makes a restassured delete call with header and body
	 * 
	 * @param headers
	 * @param jsonObject
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response putCallWithHeaderAndJsonParam(Map<String, String> headers, String jsonBodyAsString,
			String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().headers(headers).contentType(getContentType(contentType))
				.body(jsonBodyAsString).log().all().when().put(URL);
	}

	/**
	 * Wrapper method which makes a restassured put call with body, header and
	 * content type
	 * 
	 * @param headers
	 * @param jsonBodyAsString
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response putCallWithHeaderAndBodyParam(Map<String, String> headers, String jsonBodyAsString,
			String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().headers(headers).contentType(getContentType(contentType))
				.body(jsonBodyAsString).log().all().when().put(URL);
	}

	/**
	 * Wrapper method which makes a restassured put call with body and content
	 * type
	 * 
	 * @param jsonObject
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response putCallWithJsonBodyParam(String jsonBodyAsString, String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().contentType(getContentType(contentType))
				.body(jsonBodyAsString).log().all().when().put(URL);
	}

	/**
	 * Wrapper method which makes a restassured put call with header and path
	 * parameters
	 * 
	 * @param headers
	 * @param pathParams
	 * @param jsonBodyAsString
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response putCallWithHeaderAndPathParamAndJsonBody(Map<String, String> headers,
			Map<String, String> pathParams, String jsonBodyAsString, String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().contentType(getContentType(contentType)).headers(headers)
				.pathParams(pathParams).body(jsonBodyAsString).log().all().when().put(URL);
	}

	public static Response getCallWithPathParams(Map<String, String> pathParams, String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().contentType(getContentType(contentType))
				.pathParams(pathParams).log().all().get(URL);
	}

	/**
	 * Wrapper method which makes a restassured get call with path parameter
	 * 
	 * @param pathParams
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response getCallWithPathParam(Map<String, String> pathParams, String URL, String contentType) {
		return SerenityRest.given().urlEncodingEnabled(false).relaxedHTTPSValidation()
				.contentType(getContentType(contentType)).pathParams(pathParams).log().all().get(URL);
	}

	/**
	 * Wrapper method which makes a restassured post call with headers and form
	 * parameter
	 * 
	 * @param jsonObject
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response postCallWithJsonBodyParam(String jsonBodyAsString, String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().contentType(getContentType(contentType))
				.body(jsonBodyAsString).log().all().when().post(URL);
	}

	public static Response postCallWithPathParamsAndHeadersAndRequestBody(Map<String, String> pathParams,
			Map<String, String> headers, String jsonBodyAsString, String URL, String contentType) {
		return SerenityRest.given()
				.config(RestAssured.config()
						.encoderConfig(encoderconfig.appendDefaultContentCharsetToContentTypeIfUndefined(false)))
				.relaxedHTTPSValidation().pathParams(pathParams).headers(headers)
				.contentType(getContentType(contentType)).body(jsonBodyAsString).log().all().when().post(URL);
	}

	public static Response deleteCallWithHeaderPathParam(Map<String, String> pathParams, Map<String, String> headers,
			String URL, String contentType) {
		return SerenityRest.given()
				.config(RestAssured.config()
						.encoderConfig(encoderconfig.appendDefaultContentCharsetToContentTypeIfUndefined(false)))
				.relaxedHTTPSValidation().pathParams(pathParams).headers(headers)
				.contentType(getContentType(contentType)).log().all().when().post(URL);
	}

	/**
	 * Wrapper method which makes a restassured post call with headers and path
	 * parameter
	 * 
	 * @param headers
	 * @param pathParam
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response postCallWithHeaderAndPathParam(Map<String, String> headers, Map<String, String> pathParam,
			String URL, String contentType) {
		return SerenityRest.given().relaxedHTTPSValidation().headers(headers).pathParams(pathParam)
				.contentType(getContentType(contentType)).log().all().when().post(URL);
	}

	private static ContentType getContentType(String contentType) {
		if (contentType.equalsIgnoreCase("JSON")) {
			return ContentType.JSON;
		}
		if (contentType.equalsIgnoreCase("URLENC")) {
			return ContentType.URLENC;
		}
		if (contentType.equalsIgnoreCase("TEXT")) {
			return ContentType.TEXT;
		}
		if (contentType.equalsIgnoreCase("HTML")) {
			return ContentType.HTML;
		}
		if (contentType.equalsIgnoreCase("BINARY")) {
			return ContentType.BINARY;
		}
		if (contentType.equalsIgnoreCase("XML")) {
			return ContentType.XML;
		}
		if (contentType.equalsIgnoreCase("")) {
			return ContentType.JSON;
		}
		if (contentType.equalsIgnoreCase("Any")) {
			return ContentType.ANY;
		}
		return null;
	}

	public static Response deleteCallWithHeaderAndPathParam(Map<String, String> pathParams, Map<String, String> headers,
			String URL, String contentType) {
		return SerenityRest.given()
				.config(RestAssured.config()
						.encoderConfig(encoderconfig.appendDefaultContentCharsetToContentTypeIfUndefined(false)))
				.relaxedHTTPSValidation().pathParams(pathParams).headers(headers)
				.contentType(getContentType(contentType)).log().all().when().delete(URL);
	}

	public static Response getCallWithPathParamAndHeader(Map<String, String> pathParam, Map<String, String> headers,
			String URL, String contentType) {
		return SerenityRest.given()
				.config(RestAssured.config()
						.encoderConfig(encoderconfig.appendDefaultContentCharsetToContentTypeIfUndefined(false)))
				.relaxedHTTPSValidation().pathParams(pathParam).headers(headers)
				.contentType(getContentType(contentType)).log().all().when().get(URL);
	}

	public static Response patchCallWithHeaderAndPathParam(Map<String, String> pathParams, Map<String, String> headers,
			String jsonBodyAsString, String URL, String contentType) {
		return SerenityRest.given()
				.config(RestAssured.config()
						.encoderConfig(encoderconfig.appendDefaultContentCharsetToContentTypeIfUndefined(false)))
				.relaxedHTTPSValidation().pathParams(pathParams).headers(headers)
				.contentType(getContentType(contentType)).body(jsonBodyAsString).log().all().when().patch(URL);
	}

	/**
	 * PUT Call with Header, Path Parameter only No Request Body
	 *
	 * @param pathParams
	 * @param headers
	 * @param URL
	 * @param contentType
	 * @return @
	 */
	public static Response putCallWithHeaderAndPathParamAndNoBody(Map<String, String> pathParams,
			Map<String, String> headers, String URL, String contentType) {
		return SerenityRest.given()
				.config(RestAssured.config()
						.encoderConfig(encoderconfig.appendDefaultContentCharsetToContentTypeIfUndefined(false)))
				.relaxedHTTPSValidation().pathParams(pathParams).headers(headers)
				.contentType(getContentType(contentType)).log().all().when().put(URL);
	}

	public static Response postCallWithPathParamsAndHeaders(Map<String, String> pathParams, Map<String, String> headers,
			String URL, String contentType) {
		return SerenityRest.given()
				.config(RestAssured.config()
						.encoderConfig(encoderconfig.appendDefaultContentCharsetToContentTypeIfUndefined(false)))
				.relaxedHTTPSValidation().pathParams(pathParams).headers(headers)
				.contentType(getContentType(contentType)).log().all().when().post(URL);
	}

}
