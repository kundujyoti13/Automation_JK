package com.sample.qe.api.utility;

import static io.restassured.config.EncoderConfig.encoderConfig;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.URL;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.TimeZone;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import org.everit.json.schema.Schema;
import org.everit.json.schema.loader.SchemaLoader;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.junit.Assert;

//import com.sample.qe.api.base.SerenityBase;
import com.sample.qe.api.pojos.Environment;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.google.common.base.Charsets;
import com.google.common.io.Resources;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

import io.cucumber.datatable.DataTable;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.serenitybdd.rest.SerenityRest;

public class Utility  {

	/** @author anwar.shah */
	public static String getRandomStringWIthPrefic(String prefix) {
		String alphaNumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		StringBuilder userName = new StringBuilder();
		userName.append(prefix);
		Random rnd = new Random();
		while (userName.length() < 18) { // length of the random string.
			int index = (int) (rnd.nextFloat() * alphaNumeric.length());
			userName.append(alphaNumeric.charAt(index));
		}
		return userName.toString();
	}

	/** @author anwar.shah */
	public static String getFutureTimeStampInUtcZone(String type, int value) {
		String timeStamp = "";
		switch (type) {
		case "miliseconds":
			timeStamp = DateTime.now().withZone(DateTimeZone.UTC).plusMillis(value).toString();
			break;
		case "seconds":
			timeStamp = DateTime.now().withZone(DateTimeZone.UTC).plusSeconds(value).toString();
			break;
		case "minutes":
			timeStamp = DateTime.now().withZone(DateTimeZone.UTC).plusMinutes(value).toString();
			break;
		case "days":
			timeStamp = DateTime.now().withZone(DateTimeZone.UTC).plusDays(value).toString();
			break;
		}
		return timeStamp;
	}

	/** @author anwar.shah */
	public static String getPastTimeStampInUtcZone(String type, int value) {
		String timeStamp = "";
		switch (type) {
		case "minutes":
			timeStamp = DateTime.now().withZone(DateTimeZone.UTC).minusMinutes(value).toString();
			break;
		case "days":
			timeStamp = DateTime.now().withZone(DateTimeZone.UTC).minusDays(value).toString();
			break;
		}
		return timeStamp;
	}

	/** @author anwar.shah */
	public static RequestSpecification getRequestSpecification() {
		return new RequestSpecBuilder().build();
	}

	/** @author anwar.shah */
	public static void assertData(Object expected, Object actual) {
		Assert.assertTrue("Data Mismatch! Expected - " + expected + " :: Actual - " + actual, expected.equals(actual));
	}

	/** @author anwar.shah */
	public static String getProductCode(String productTitle, String executionEnvironment) {
		ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
		try {
			URL file = Resources.getResource("configFiles/testData/environment_config.yml");
			Environment[] environments = mapper.readValue(file, Environment[].class);
			for (Environment environment : environments) {
				if (environment.getName().equalsIgnoreCase(executionEnvironment)
						&& environment.getProducts().containsKey(productTitle))
					return environment.getProducts().get(productTitle).toString();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	/**
	 * @author Abhishek.Sharda
	 * @description Method to alter the desired key values in the JSON and
	 *              returning the JSON as string
	 * @return alteredJson as string
	 */
	public static synchronized String alterJson(String jsonName, Map<String, String> jsonValues) {
		String jsonString = null;
		try {

			// to differentiate between the jsonName as file name or jsonstring
			if (jsonName.length() < 30) {
				URL file = Resources.getResource("configFiles/jsonFiles/RequestJson/" + jsonName + ".txt");
				jsonString = Resources.toString(file, Charsets.UTF_8);
			} else {
				jsonString = jsonName;
			}

			for (Map.Entry<String, String> keyVal : jsonValues.entrySet()) {
				jsonString = jsonString.replaceAll(keyVal.getKey(), keyVal.getValue());
			}

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Exception found in alterJson method " + e.getMessage());
		}
		return jsonString;
	}

	public static void validateJsonSchema(Response response, String jsonName) {
		try {
			InputStream inputStream = response.asInputStream();
			JSONObject reponseSchema = new JSONObject(new JSONTokener(inputStream));
			JSONObject expectedJsonSchema = new JSONObject(new JSONTokener(Resources
					.getResource("configFiles/jsonFiles/responseValidatorJson/" + jsonName + ".txt").openStream()));
			Schema schema = SchemaLoader.load(expectedJsonSchema);
			schema.validate(reponseSchema);
		} catch (Exception e) {
			Assert.assertFalse("Error while validating response json schema: " + e, true);

		}
	}

	public static String getRandomString() {
		String alphaNumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		StringBuilder userName = new StringBuilder();
		userName.append("glp-");
		Random rnd = new Random();
		while (userName.length() < 18) { // length of the random string.
			int index = (int) (rnd.nextFloat() * alphaNumeric.length());
			userName.append(alphaNumeric.charAt(index));
		}

		return userName.toString();
	}

	public static String getRandomStringWithPrefix(String prefix) {
		String alphaNumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		StringBuilder userName = new StringBuilder();
		userName.append(prefix);
		Random rnd = new Random();
		while (userName.length() < 27) { // length of the random string.
			int index = (int) (rnd.nextFloat() * alphaNumeric.length());
			userName.append(alphaNumeric.charAt(index));
		}

		return userName.toString();
	}

	public static String readJson(String jsonName) {
		try {
			URL file = Resources.getResource("configFiles/jsonFiles/RequestJson/" + jsonName + ".txt");
			String jsonString = Resources.toString(file, Charsets.UTF_8);
			return jsonString;
		} catch (Exception e) {

			System.out.println("Error while altering json : " + e);
			return null;
		}
	}

	public static String createEndPoint(String base_url, String ApiEndpoint) {
		System.out.println(base_url + ApiEndpoint);
		return base_url + ApiEndpoint;
	}

	public static String readResponseJsonSchema(String jsonSchema) {
		try {
			URL file = Resources.getResource("configFiles/jsonFiles/ResponseJsonSchema/" + jsonSchema + ".json");
			String jsonString = Resources.toString(file, Charsets.UTF_8);
			return jsonString;
		} catch (Exception e) {

			System.out.println("Error while altering json : " + e);
			return null;
		}
	}

	/**
	 * @author Anwar.Shah
	 * @description Method to accept plain string and encrypt it and returning
	 *              the encrypted value as string
	 * @return encryptedString as string
	 */
	public static String getEncryptedString(String plainString) {

		String encryptedString = null;
		Cipher cipher = null;
		String AES_ALGORITHM = "AES";
		String check = "1RsBnI0xfXGaIabpJO7zaQ==";

		try {
			cipher = Cipher.getInstance(AES_ALGORITHM);
			SecretKeySpec sharedByteArray = new SecretKeySpec(Base64.getDecoder().decode(check), AES_ALGORITHM);

			try {
				byte[] plainTextByte = plainString.getBytes();
				cipher.init(Cipher.ENCRYPT_MODE, sharedByteArray);
				byte[] encryptedByte = cipher.doFinal(plainTextByte);
				Base64.Encoder encoder = Base64.getUrlEncoder();
				encryptedString = encoder.encodeToString(encryptedByte);
			} catch (GeneralSecurityException ex) {
				ex.printStackTrace();
			}
		} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
			e.printStackTrace();
		}

		return encryptedString;
	}

	public static void putVariablesInMap(Class clz) throws Exception {
		Field[] fields = clz.getFields();
		for (Field field : fields) {
			PropertyHolder.setProperty(field.getName(), (String) field.get(field));
		}
	}

	public static String getCurrentDateInUtcZone() {
		DateTime dt = new DateTime();
		return (dt.now().withZone(DateTimeZone.UTC).toString());
	}

	public static String getFutureDateTime(int days) {
		return new DateTime().now().withZone(DateTimeZone.UTC).plusDays(days).toString();
	}

	/**
	 * * @author Amirthavalli DP
	 * 
	 * @description Method to return future date/time
	 * @parameters intDays days to be added
	 * @parameters intMinutes minutes to be added
	 * @parameters intSeconds seconds to be added
	 * @return date time as string
	 */
	/*
	 * public static String getFutureDateTime(int intDays,int intMinutes, int
	 * intSeconds) { return new
	 * DateTime().now().withZone(DateTimeZone.UTC).plusDays(intDays).plusMinutes
	 * (intMinutes).plusSeconds(intSeconds).toString(); }
	 */

	public static String getPastDateTime(int days) {
		return new DateTime().now().withZone(DateTimeZone.UTC).minusDays(days).toString();
	}

	public static Object addKeyInJsonString(String jsonPayload, String jPath, String keyValue) {
		JSONObject reqObj = null;
		try {

			Object document = Configuration.defaultConfiguration().jsonProvider().parse(jsonPayload);
			Object addObject = Configuration.defaultConfiguration().jsonProvider().parse(keyValue.split("~")[1]);
			DocumentContext UpdateJson = com.jayway.jsonpath.JsonPath.parse(document).put(jPath, keyValue.split("~")[0],
					addObject);
			reqObj = new JSONObject(UpdateJson.jsonString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return reqObj;
	}

	public static Map<String, String> getMapFromDataTableUsingKey(DataTable table, String key) {
		Map<String, String> map = new HashMap<String, String>();
		for (int i = 0; i < table.cells().size(); i++) {
			if (table.cells().get(i).get(0).equalsIgnoreCase(key)) {
				map.put(table.cells().get(i).get(1), PropertyHolder.getProperty(table.cells().get(i).get(2)) == null
						? table.cells().get(i).get(2) : PropertyHolder.getProperty(table.cells().get(i).get(2)));
			}
		}
		return map;
	}

	public static Response doRequest(RequestSpecification requestSpec, String methodType, String url) {
		switch (methodType.toLowerCase()) {
		case "get":
			return requestSpec.relaxedHTTPSValidation().log().all().get(url);
		case "post":
			return requestSpec.relaxedHTTPSValidation().log().all().post(url);
		case "put":
			return requestSpec.relaxedHTTPSValidation().log().all().put(url);
		case "delete":
			return requestSpec.relaxedHTTPSValidation().log().all().delete(url);
		case "patch":
			return requestSpec.relaxedHTTPSValidation().log().all().patch(url);
		default:
			Assert.assertTrue("Invalid method type passed: " + methodType, false);
			return null;
		}
	}

	/**
	 * * @author Senthilvel.S
	 * 
	 * @description Method to return ContentType value as string
	 * @return ContentType as string
	 */
	public static String getContentTypeFromDataTable(DataTable table) {
		String contentType = null;
		for (int i = 0; i < table.cells().size(); i++) {
			if (table.cells().get(i).get(0).equalsIgnoreCase("contenttype")) {
				contentType = table.cells().get(i).get(1);
			}
		}
		return contentType;
	}

	public static String getDate(String reqValues) {
		String date = reqValues;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.000'Z'");
		Date myDate = new Date(System.currentTimeMillis());
		Calendar cal = Calendar.getInstance();
		if (date.equalsIgnoreCase("currentDate")) {
			date = dateFormat.format(myDate);
		} else if (date.equalsIgnoreCase("pastDate")) {
			cal.setTime(myDate);
			cal.add(Calendar.DATE, -10);
			date = dateFormat.format(cal.getTime());
		} else if (date.equalsIgnoreCase("FutureDate")) {
			cal.setTime(myDate);
			cal.add(Calendar.DATE, 10);
			date = dateFormat.format(cal.getTime());
		}
		return date;
	}

	/**
	 * @author Amirthavalli DP
	 * @description Method to return a string appending the current date and
	 *              time
	 * @parameters intDays days to be added
	 * @parameters intMinutes minutes to be added
	 * @parameters intSeconds seconds to be added
	 * @return date time as string
	 */
	public static String getRandomStringWithCurrentTime(String prefix) {

		StringBuilder userName = new StringBuilder();
		userName.append(prefix);
		SimpleDateFormat dateTimeInGMT = new SimpleDateFormat("dd-MMM HH:mm");
		dateTimeInGMT.setTimeZone(TimeZone.getTimeZone("UTC"));
		String formattedDate = dateTimeInGMT.format(new Date());
		userName = userName.append(formattedDate);
		String strName = userName.toString().replace("-", "_").replace(" ", "_").replaceAll(":", "_");
		return strName;

	}

	/**
	 * Removes the key from json.
	 *
	 * @param json
	 *            the json in which key to be removed
	 * @param JPath
	 *            the jsonpath at which key to be removed
	 * @return the updated json in string
	 */
	public static String removeKeyFromJson(String json, String JPath) {
		DocumentContext updateJson = null;
		try {
			Object document = Configuration.defaultConfiguration().jsonProvider().parse(json);
			updateJson = JsonPath.parse(document).delete(PropertyHolder.getProperty(JPath) == null ? JPath : PropertyHolder.getProperty(JPath));
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Exception found in removeKeyFromJson method:" + e);
		}
		return updateJson.jsonString();
	}

	public static Object AddKeyInJson(String JsonFileName, String JPath) {
		String jsonString = null;
		JSONObject ReqObj = null;
		try {
			URL file = Resources.getResource("configFiles/jsonFiles/RequestJson/" + JsonFileName + ".txt");
			jsonString = Resources.toString(file, Charsets.UTF_8);
			Object document = Configuration.defaultConfiguration().jsonProvider().parse(jsonString);

			DocumentContext UpdateJson = com.jayway.jsonpath.JsonPath.parse(document).put(JPath.split("-")[0],
					JPath.split("-")[1], JPath.split("-")[2]);
			ReqObj = new JSONObject(UpdateJson.jsonString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ReqObj;
	}

	public static String CreateAssignmentRequest(Map<String, String> assDetails, int intAUCount) throws JSONException {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("title", assDetails.get("ASSIGNMENT_TITLE"));
		jsonObject.put("dueDate", assDetails.get("ASSI_DUE_DATE"));
		jsonObject.put("studentMessage", "Student Test Message");
		jsonObject.put("availableDate", assDetails.get("ASSIGNT_AVAI_DATE"));

		JSONArray AU = new JSONArray();

		// AU1
		if (intAUCount == 1 || intAUCount == 2) {
			JSONObject AU1 = new JSONObject();
			AU1.put("id", assDetails.get("ASSI_UNIT_ID1"));
			AU1.put("dueDate", assDetails.get("ASSI_UNIT_DUE_DATE1"));
			AU1.put("availableDate", assDetails.get("ASSI_UNIT_AVAI_DATE1"));
			AU.put(AU1); // add to products
		}
		if (intAUCount == 2) {
			// AU2
			JSONObject AU2 = new JSONObject();
			AU2.put("id", assDetails.get("ASSI_UNIT_ID2"));
			AU2.put("dueDate", assDetails.get("ASSI_UNIT_DUE_DATE2"));
			AU2.put("availableDate", assDetails.get("ASSI_UNIT_AVAI_DATE2"));
			AU.put(AU2); // add to products
		}
		jsonObject.put("assignedUnits", AU); // add products array to the
												// top-level json object
		jsonObject.put("publishedDate", assDetails.get("ASSI_PUBLISH_DATE"));

		System.out.println(jsonObject.toString());
		return jsonObject.toString();
	}

	public static String getFutureTime(int seconds) {
		return new DateTime().now().withZone(DateTimeZone.UTC).plusSeconds(seconds).toString();
	}

	public static String modifyCurrentDateTime(String type, int valueToModify) {
		try {
			String date = null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:00'Z'");
			dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
			Date currentDateTime = new Date(System.currentTimeMillis());
			Calendar calender = Calendar.getInstance();
			calender.setTime(currentDateTime);
			if (type.equalsIgnoreCase("minute")) {
				calender.add(Calendar.MINUTE, valueToModify);
				date = dateFormat.format(calender.getTime());
			} else if (type.equalsIgnoreCase("date")) {
				calender.add(Calendar.DATE, valueToModify);
				date = dateFormat.format(calender.getTime());
			} else if (type.equalsIgnoreCase("hour")) {
				calender.add(Calendar.HOUR, valueToModify);
				date = dateFormat.format(calender.getTime());
			} else if (type.equalsIgnoreCase("seconds")) {
				calender.add(Calendar.SECOND, valueToModify);
				date = dateFormat.format(calender.getTime());
			} else {
				// APP_LOG.info("Check for parameters");
				date = null;
				Assert.assertFalse("Check for parameters", true);
			}
			return date;
		} catch (Exception e) {
			// APP_LOG.error("Exception: " + e);
			Assert.assertFalse("Exception: " + e, true);
			return null;
		}
	}

	public static String updateRequestBody(DataTable table, String jsonBody) {
		for (int i = 0; i < table.cells().size(); i++) {
			switch (table.cells().get(i).get(0).toLowerCase()) {
			case "key to be update": {
				jsonBody = Utility.updateKeyValueInJson(jsonBody, table.cells().get(i).get(1),
						table.cells().get(i).get(2));
				break;
			}
			case "key to be add": {
				jsonBody = Utility.addKeyInJson(jsonBody, table.cells().get(i).get(1), table.cells().get(i).get(2));
				break;
			}
			case "key to be remove": {
				jsonBody = Utility.removeKeyFromJson(jsonBody, table.cells().get(i).get(1));
				break;
			}
			case "environment key": {
			//	jsonBody = Utility.updateKeyValueInJson(jsonBody, table.cells().get(i).get(1),
			//			configurationsXlsMap.get(table.cells().get(i).get(2)));
				break;
			}

			}

		}
		return jsonBody;
	}

	public static String updateKeyValueInJson(String json, String jsonPath, String valueToBeUpdated) {
		DocumentContext updateJson = null;
		try {
			Object document = Configuration.defaultConfiguration().jsonProvider().parse(json);
			valueToBeUpdated = checkIfGivenStringIsSomeKeyword(valueToBeUpdated);
			jsonPath = PropertyHolder.getProperty(jsonPath) == null ? jsonPath : PropertyHolder.getProperty(jsonPath);

			Object addObject = Configuration.defaultConfiguration().jsonProvider().parse(valueToBeUpdated);

			updateJson = JsonPath.parse(document).set(jsonPath, addObject);
		} catch (Exception e) {
			Assert.assertTrue(e.getMessage(), false);
		}
		return updateJson.jsonString();
	}

	private static String checkIfGivenStringIsSomeKeyword(String keyword) {
		String newKeyword = "";
		if (keyword.startsWith("(")) {
			String key = keyword.substring(1, keyword.length() - 1);
			if (key.contains(",") || key.contains("=")) {
				if (key.contains(",") && key.contains("=")) {
					String[] keyValuePair = key.split(",");
					for (int i = 0; i < keyValuePair.length; i++) {
						String[] keyValue = keyValuePair[i].split("=");
						keyValue[1] = getKeywordValue(keyValue[1]);
						keyValuePair[i] = keyValue[0].concat("=").concat(keyValue[1]);
					}

					for (int i = 0; i < keyValuePair.length; i++) {
						newKeyword += keyValuePair[i].concat(",");
					}
					newKeyword = "(".concat(newKeyword.substring(0, newKeyword.length() - 1)).concat(")");

				}
				if (key.contains("=") && (!key.contains(","))) {
					String[] keyValue = key.split("=");
					keyValue[1] = getKeywordValue(keyValue[1]);
					newKeyword = "(".concat(keyValue[0].concat("=").concat(keyValue[1])).concat(")");

				}

			} else {
				newKeyword = "(".concat(getKeywordValue(key)).concat(")");
			}
		} else {
			newKeyword = getKeywordValue(keyword);
		}
		return newKeyword;
	}

	public static String getKeywordValue(String keyword) {
		if (keyword.contains("Invalid UUID")) {
			PropertyHolder.setProperty(keyword, getInvalidUUID());
		} else if (keyword.contains("Valid UUID")) {
			PropertyHolder.setProperty(keyword, generateRandomUUID());
		} else if (keyword.contains("Valid date")) {
			PropertyHolder.setProperty(keyword, getDateAndTimeInUTC());
		} else if (keyword.contains("Random String")) {
			PropertyHolder.setProperty(keyword, getRandomString());
		} else if (keyword.contains("Object")) {
			PropertyHolder.setProperty(keyword, new JSONObject().toString());
		} else if (keyword.contains("Array")) {
			PropertyHolder.setProperty(keyword, new JSONArray().toString());
		} else if (keyword.contains("prevDate")) {
			PropertyHolder.setProperty(keyword, getPastDateTimeStamp(1));
		} else if (keyword.contains("nextDate")) {
			PropertyHolder.setProperty(keyword, getFutureDateTimeStamp(1));
		}

		return PropertyHolder.getProperty(keyword) ;
			//	? (configurationsXlsMap.get(keyword) == null ? keyword : configurationsXlsMap.get(keyword))
			//	: PropertyHolder.getProperty(keyword);
//
	}

	public static String getInvalidUUID() {
		return generateRandomUUID().substring(0, 10);
	}

	public static String generateRandomUUID() {
		String uuid = UUID.randomUUID().toString();
		System.out.println("Generated UUID : " + uuid);
		return uuid;
	}

	public static String getDateAndTimeInUTC() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ssZ");
		format.setTimeZone(TimeZone.getTimeZone("UTC"));
		return format.format(new Date());
	}

	public static String getPastDateTimeStamp(int days) {
		return new DateTime().now().withZone(DateTimeZone.UTC).minusDays(days).toString();
	}

	public static String getFutureDateTimeStamp(int days) {
		return new DateTime().now().withZone(DateTimeZone.UTC).plusDays(days).toString();
	}

	public static String addKeyInJson(String json, String jPath, String keyValue) {
		DocumentContext updateJson = null;
		try {

			Object document = Configuration.defaultConfiguration().jsonProvider().parse(json);
			Object addObject = Configuration.defaultConfiguration().jsonProvider().parse(keyValue.split("-")[1]);
			updateJson = JsonPath.parse(document).put(jPath, keyValue.split("-")[0], addObject);
		} catch (Exception e) {
			Assert.assertTrue(e.getMessage(), false);
		}
		return updateJson.jsonString();
	}

	public static Response buildRequest(DataTable table, String methodType) {
		RequestSpecification request = SerenityRest.given()
				.contentType(getContentTypeFromDataTable(table) == null ? "application/json"
						: getContentTypeFromDataTable(table))
				.headers(Utility.setValuesInMap(getMapFromDataTableUsingKey(table, "header")))
				.formParams(Utility.setValuesInMap(getMapFromDataTableUsingKey(table, "formParam")))
				.pathParams(Utility.setValuesInMap(getMapFromDataTableUsingKey(table, "pathParam")))
				.queryParams(Utility.setValuesInMap(getMapFromDataTableUsingKey(table, "queryParam")))
				.config(RestAssured.config()
						.encoderConfig(encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)));

		if (methodType.equalsIgnoreCase("get") || methodType.equalsIgnoreCase("delete")) {
			return doRequest(request, methodType, PropertyHolder.getProperty("Url"));
		} else {

			return doRequest(request.body(PropertyHolder.getProperty("requestBody")), methodType,
					PropertyHolder.getProperty("Url"));
		}
	}

	public static Map<String, String> setValuesInMap(Map<String, String> map) {
		for (Map.Entry<String, String> entry : map.entrySet()) {
			String updatedValue = checkIfGivenStringIsSomeKeyword(entry.getValue());
			map.put(entry.getKey(), updatedValue);
		}
		return map;
	}

	public static String getKeyValueFromJsonUsingJsonPath(String json, String jsonPath) {
		String updateJson = null;
		try {

			Object document = Configuration.defaultConfiguration().jsonProvider().parse(json);
			updateJson = JsonPath.parse(document).read(PropertyHolder.getProperty(jsonPath) == null ? jsonPath : PropertyHolder.getProperty(jsonPath))
					.toString();

	//		APP_LOG.info("Got key value for " + jsonPath + " as " + updateJson);

		} catch (Exception e) {
			Assert.assertTrue(e.getMessage(), false);
		}
		return updateJson;
	}

	public static void compareValues(String actualValue, String expectedValue) {
		Assert.assertTrue(
				"Values are not matching, actual value: " + actualValue + ", but expected was: " + expectedValue,
				actualValue.equals(expectedValue));
	}

	public static String generateRandomString(int numofChars) {
		try {
			String inputAlphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
			StringBuilder inputString = new StringBuilder();
			SecureRandom rnd = new SecureRandom();
			while (inputString.length() < numofChars) {
				// string.
				int index = (int) (rnd.nextDouble() * inputAlphabets.length());
				inputString.append(inputAlphabets.charAt(index));
			}
			String FinalStr = inputString.toString();
	//		APP_LOG.info(FinalStr);
			return FinalStr;
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}

	public static String UpdateValueUsingJsonString(String jsonString, String JPath, String Value) {
		DocumentContext updateJson = null;
		try {
			Object document = Configuration.defaultConfiguration().jsonProvider().parse(jsonString);
			Value = checkIfGivenStringIsSomeKeyword1(Value);
			JPath = PropertyHolder.getProperty(JPath) == null ? JPath : PropertyHolder.getProperty(JPath);
			if (Value.equalsIgnoreCase("BLANK")) {
				Value = "";
			}
			updateJson = com.jayway.jsonpath.JsonPath.parse(document).set(JPath, Value);
		} catch (Exception e) {
	//		APP_LOG.error("Error while AddKeyUsingJsonString : " + e);
		}
		return updateJson.jsonString();
	}
	public static String checkIfGivenStringIsSomeKeyword1(String keyword) {
		if (keyword.contains("Invalid UUID")) {
			PropertyHolder.setProperty(keyword, getInvalidUUID());
		} else if (keyword.contains("Valid UUID")) {
			PropertyHolder.setProperty(keyword, generateRandomUUID());
		} else if (keyword.contains("Valid date")) {
			PropertyHolder.setProperty(keyword, getDateAndTimeInUTC());
		} else if (keyword.contains("narrativeModel_id")) {
		//	PropertyHolder.setProperty(keyword, configurationsXlsMap.get("narrativeModel_id"));
		} else if (keyword.contains("narrativeModel_ver")) {
		//	PropertyHolder.setProperty(keyword, configurationsXlsMap.get("narrativeModel_ver"));
		} else if (keyword.contains("assessmentItemModel_id")) {
		//	PropertyHolder.setProperty(keyword, configurationsXlsMap.get("assessmentItemModel_id"));
		} else if (keyword.contains("assessmentItemModel_ver")) {
		//	PropertyHolder.setProperty(keyword, configurationsXlsMap.get("assessmentItemModel_ver"));
		} else if (keyword.contains("assessmentModel_id")) {
		//	PropertyHolder.setProperty(keyword, configurationsXlsMap.get("assessmentModel_id"));
		} else if (keyword.contains("assessmentModel_ver")) {
		//	PropertyHolder.setProperty(keyword, configurationsXlsMap.get("assessmentModel_ver"));
		} else if (keyword.contains("aggregateModel_id")) {
		//	PropertyHolder.setProperty(keyword, configurationsXlsMap.get("aggregateModel_id"));
		} else if (keyword.contains("aggregateModel_ver")) {
		//	PropertyHolder.setProperty(keyword, configurationsXlsMap.get("aggregateModel_ver"));
		} else if (keyword.contains("productModel_id")) {
		//	PropertyHolder.setProperty(keyword, configurationsXlsMap.get("productModel_id"));
		} else if (keyword.contains("productModel_ver")) {
		//	PropertyHolder.setProperty(keyword, configurationsXlsMap.get("productModel_ver"));
		}

		return PropertyHolder.getProperty(keyword) == null ? keyword : PropertyHolder.getProperty(keyword);

	}

	public static String alterJsonBodyUsingDataTable(String FileName, DataTable dt) {
		Map<String, String> alter = new HashMap<>();
		for (int i = 0; i < dt.row(0).size(); i++) {
			String dtKey = dt.row(0).get(i);
			String dtValue = dt.row(1).get(i);
			if (dtKey.equals("VexpiresOn") && dtValue.contains("DateTime")) {
				switch (dtValue) {
				case "currentDateTime":
					alter.put(dtKey, getCurrentDateInUtcZone());
					break;
				case "futureDateTime":
					alter.put(dtKey, getTomorrowsDateTime());
					break;
				case "nextHourDateTime":
					alter.put(dtKey, getNextHourDateTime());
					break;
				case "nextMinDateTime":
					alter.put(dtKey, getNextMinDateTime());
					break;
				case "pastDateTime":
					alter.put(dtKey, getYesterdaysDateTime());
					break;
				case "pastHourDateTime":
					alter.put(dtKey, getPastHourDateTime());
					break;
				case "pastMinDateTime":
					alter.put(dtKey, getPastMinDateTime());
					break;
				case "istZoneDateTime":
					alter.put(dtKey, getDateTimeInNonUtcZone());
					break;
				}
			} else {
				if (PropertyHolder.booleanProperty(dtValue)) {
					alter.put(dtKey, PropertyHolder.getProperty(dtValue));
				} else {
					alter.put(dtKey, dtValue);
				}

			}
		}

		String jsonString = alterJson(FileName, alter);
		return jsonString;
	}

	public static String getTomorrowsDateTime() {
		String futureDate = DateTime.now().withZone(DateTimeZone.UTC).plusDays(1)
				.toString("yyyy-MM-dd'T'HH:mm:ss+00:00");
		return futureDate;
	}

	public static String getNextHourDateTime() {
		String nextHourDateTime = DateTime.now().withZone(DateTimeZone.UTC).plusHours(1)
				.toString("yyyy-MM-dd'T'HH:mm:ss+00:00");
		return nextHourDateTime;
	}

	public static String getNextMinDateTime() {
		String nextMinDateTime = DateTime.now().withZone(DateTimeZone.UTC).plusMinutes(2)
				.toString("yyyy-MM-dd'T'HH:mm:ss+00:00");
		return nextMinDateTime;
	}

	public static String getYesterdaysDateTime() {
		String pastDate = DateTime.now().withZone(DateTimeZone.UTC).minusDays(1)
				.toString("yyyy-MM-dd'T'HH:mm:ss+00:00");
		return pastDate;
	}

	public static String getPastHourDateTime() {
		String pastHourDateTime = DateTime.now().withZone(DateTimeZone.UTC).minusHours(1)
				.toString("yyyy-MM-dd'T'HH:mm:ss+00:00");
		return pastHourDateTime;
	}

	public static String getPastMinDateTime() {
		String pastMinDateTime = DateTime.now().withZone(DateTimeZone.UTC).minusMinutes(2)
				.toString("yyyy-MM-dd'T'HH:mm:ss+00:00");
		return pastMinDateTime;
	}

	public static String getDateTimeInNonUtcZone() {
		String defaultZoneDateTime = DateTime.now().toString();
		return defaultZoneDateTime;
	}

	@SuppressWarnings("rawtypes")
	public Map<String, String> getMapOfJsonPath(Class cls) {
		Map<String, String> jsonPathMap = new HashMap<String, String>();
		try {

			for (Field fields : cls.getFields()) {
				jsonPathMap.put(fields.getName(), fields.get(fields.getName()).toString());
			}
		} catch (Exception e) {
		//	APP_LOG.error(e.getMessage());
		}
		return jsonPathMap;
	}

	public static String GetKeyValueFromJson(String Json, String JPath) {
		Object object = null;
		try {
			Object document = Configuration.defaultConfiguration().jsonProvider().parse(Json);
			object = JsonPath.read(document, JPath);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return object.toString().replace("[", "").replace("]", "").replace("\"", "").trim();
	}

}
